import csv
import re
from collections import defaultdict

def read_data(filename):
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        data = list(reader)
        fieldnames = reader.fieldnames
    return data, fieldnames

def ques1(data):
    for row in data:
        age = row['age']
        if re.match(r'\d+-\d+', age):
            start, end = map(int, age.split('-'))
            avg = (start + end) / 2
            row['age'] = str(round(avg))

def ques2(data):
    date_columns = ['date_onset_symptoms', 'date_admission_hospital', 'date_confirmation']
    for row in data:
        for col in date_columns:
            date = row[col]
            if date and date != 'NaN':
                parts = date.split('.')
                if len(parts) == 3:
                    row[col] = f"{parts[1]}.{parts[0]}.{parts[2]}"

def ques3(data):
    province_lat = defaultdict(list)
    province_lon = defaultdict(list)
    for row in data:
        province = row['province']
        if row['latitude'].lower() != 'nan' and row['latitude']:
            province_lat[province].append(float(row['latitude']))
        if row['longitude'].lower() != 'nan' and row['longitude']:
            province_lon[province].append(float(row['longitude']))
    
    avg_lat = {p: round(sum(vals)/len(vals), 2) if vals else 0.0 for p, vals in province_lat.items()}
    avg_lon = {p: round(sum(vals)/len(vals), 2) if vals else 0.0 for p, vals in province_lon.items()}
    
    for row in data:
        province = row['province']
        if row['latitude'].lower() == 'nan' or not row['latitude']:
            row['latitude'] = str(avg_lat.get(province, 0.0))
        if row['longitude'].lower() == 'nan' or not row['longitude']:
            row['longitude'] = str(avg_lon.get(province, 0.0))

def ques4(data):
    province_city = defaultdict(lambda: defaultdict(int))
    for row in data:
        province = row['province']
        city = row['city']
        if city and city.lower() != 'nan':
            province_city[province][city] += 1
    
    common_city = {}
    for p, cities in province_city.items():
        max_count = max(cities.values(), default=0)
        candidates = sorted([city for city, cnt in cities.items() if cnt == max_count])
        common_city[p] = candidates[0] if candidates else ''
    
    for row in data:
        province = row['province']
        if row['city'].lower() == 'nan' or not row['city']:
            row['city'] = common_city.get(province, '')

def ques5(data):
    province_symptoms = defaultdict(lambda: defaultdict(int))
    for row in data:
        province = row['province']
        symptoms = row['symptoms']
        if symptoms and symptoms.lower() != 'nan':
            symptoms = re.split(r'; |;', symptoms)
            for s in symptoms:
                s = s.strip()
                if s:
                    province_symptoms[province][s] += 1
    
    common_symptom = {}
    for p, symptoms in province_symptoms.items():
        max_count = max(symptoms.values(), default=0)
        candidates = sorted([s for s, cnt in symptoms.items() if cnt == max_count])
        common_symptom[p] = candidates[0] if candidates else ''
    
    for row in data:
        province = row['province']
        if row['symptoms'].lower() == 'nan' or not row['symptoms']:
            row['symptoms'] = common_symptom.get(province, '')

def write_result(data, fieldnames, filename):
    with open(filename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

def main():
    data, fieldnames = read_data('covidTrain.csv')
    ques1(data)
    ques2(data)
    ques3(data)
    ques4(data)
    ques5(data)
    write_result(data, fieldnames, 'covidResult.csv')

main()