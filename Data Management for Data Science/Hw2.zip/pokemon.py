import pandas as pd
import numpy as np
from collections import defaultdict

def main():
    # ----------------------------------------------------
    # 1) Read the CSV and compute:
    #    "Percentage of fire type Pokemons at or above level 40"
    # ----------------------------------------------------
    df = pd.read_csv("pokemonTrain.csv")

    # Ensure level column is numeric
    df["level"] = pd.to_numeric(df["level"], errors="coerce")

    # Filter to fire‐type Pokemons only
    fire_pokemon = df[df["type"] == "fire"]

    # Edge case: if there are no fire pokemons at all, handle gracefully
    if len(fire_pokemon) == 0:
        pct = 0
    else:
        # Count how many have level >= 40
        count_ge40 = (fire_pokemon["level"] >= 40).sum()
        total_fire = len(fire_pokemon)
        # Calculate percentage (over fire pokemons only)
        pct = (count_ge40 / total_fire) * 100

    # Round the percentage using round() function
    pct_rounded = round(pct)

    # Print the result to file "pokemon1.txt"
    with open("pokemon1.txt", "w") as f_out:
        f_out.write(f"Percentage of fire type Pokemons at or above level 40 = {pct_rounded}\n")

    # ----------------------------------------------------
    # 2) Fill in missing "type" by using the most common type 
    #    for that "weakness" (tie → alphabetical).
    # ----------------------------------------------------
    weakness_to_type_map = {}

    # For each unique weakness (ignoring NaN values)
    for w in df["weakness"].dropna().unique():
        sub = df[(df["weakness"] == w) & (df["type"].notna())]
        if len(sub) == 0:
            continue
        # Count the frequency of each type for this weakness
        type_counts = sub["type"].value_counts()
        max_freq = type_counts.max()  # maximum frequency
        types_with_max = type_counts[type_counts == max_freq].index.tolist()
        # In case of tie, choose the alphabetically first type
        winner = sorted(types_with_max)[0]
        weakness_to_type_map[w] = winner

    # Function to fill missing type values using the map above
    def fill_type(row):
        if pd.isna(row["type"]):
            w = row["weakness"]
            if w in weakness_to_type_map:
                return weakness_to_type_map[w]
            else:
                return np.nan  # cannot fill if no mapping exists
        else:
            return row["type"]

    df["type"] = df.apply(fill_type, axis=1)

    # ----------------------------------------------------
    # 3) Fill in missing atk/def/hp based on level threshold 40
    # ----------------------------------------------------
    # Compute average values for Pokemons with level > 40 and <= 40
    above_40 = df[df["level"] > 40]
    below_eq_40 = df[df["level"] <= 40]

    avg_above_40_atk = round(above_40["atk"].mean(), 1)
    avg_above_40_def = round(above_40["def"].mean(), 1)
    avg_above_40_hp  = round(above_40["hp"].mean(), 1)

    avg_below_40_atk = round(below_eq_40["atk"].mean(), 1)
    avg_below_40_def = round(below_eq_40["def"].mean(), 1)
    avg_below_40_hp  = round(below_eq_40["hp"].mean(), 1)

    # Function to fill missing atk, def, and hp values based on level
    def fill_stats(row):
        if pd.isna(row["atk"]):
            if row["level"] > 40:
                row["atk"] = avg_above_40_atk
            else:
                row["atk"] = avg_below_40_atk
        if pd.isna(row["def"]):
            if row["level"] > 40:
                row["def"] = avg_above_40_def
            else:
                row["def"] = avg_below_40_def
        if pd.isna(row["hp"]):
            if row["level"] > 40:
                row["hp"] = avg_above_40_hp
            else:
                row["hp"] = avg_below_40_hp
        return row

    df = df.apply(fill_stats, axis=1)

    # Write the modified DataFrame to "pokemonResult.csv"
    df.to_csv("pokemonResult.csv", index=False)

    # ----------------------------------------------------
    # 4) Create a dictionary: type -> list of personalities,
    # ----------------------------------------------------
    df_result = pd.read_csv("pokemonResult.csv")
    type_to_personalities = defaultdict(set)

    for _, row in df_result.iterrows():
        pokemon_type = row["type"]
        personality = row["personality"]
        if pd.notna(pokemon_type) and pd.notna(personality):
            type_to_personalities[pokemon_type].add(personality)

    with open("pokemon4.txt", "w") as f_out:
        f_out.write("Pokemon type to personality mapping:\n\n")
        # Sort type keys alphabetically, and sort personalities for each type
        for t in sorted(type_to_personalities.keys()):
            sorted_pers = sorted(type_to_personalities[t])
            personalities_str = ", ".join(sorted_pers)
            f_out.write(f"   {t}: {personalities_str}\n")

    # ----------------------------------------------------
    # 5) Find average hp for pokemons of stage 3.0
    # ----------------------------------------------------
    stage3 = df_result[df_result["stage"] == 3.0]
    if len(stage3) == 0:
        avg_hp_stage3 = 0.0
    else:
        avg_hp_stage3 = stage3["hp"].mean()

    avg_hp_stage3_rounded = round(avg_hp_stage3)

    with open("pokemon5.txt", "w") as f_out:
        f_out.write(f"Average hit point for Pokemons of stage 3.0 = {avg_hp_stage3_rounded}\n")
    pass
main()
