import re
import math
from collections import Counter, defaultdict

def load_stopwords(filename="stopwords.txt"):
    """Loads stopwords from the given file into a set."""
    stopwords = set()
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            word = line.strip()
            if word:
                stopwords.add(word)  
    return stopwords

def preprocess_text(text, stopwords):
    """
    Preprocess the text by performing the following steps:
    1) Remove links (http/https)
    2) Remove non-alphanumeric/underscore characters
    3) Remove extra spaces
    4) Convert to lowercase
    5) Remove stopwords
    6) Apply simple stemming rules
    """
    # 1) Remove website links
    text = re.sub(r'https?://\S+', '', text)
    # 2) Remove all non-word characters except spaces
    text = re.sub(r'[^\w\s]', '', text)
    # 3) Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    # 4) Convert to lowercase
    text = text.lower()
    # Split into words
    words = text.split()
    # 5) Remove stopwords
    words = [word for word in words if word not in stopwords]
    # 6) Simple stemming
    processed_words = []
    for word in words:
        if word.endswith("ing") and len(word) > 3:
            word = word[:-3]  # Remove "ing" from words
        elif word.endswith("ly") and len(word) > 2:
            word = word[:-2]  # Remove "ly" from words
        elif word.endswith("ment") and len(word) > 4:
            word = word[:-4]  # Remove "ment" from words
        processed_words.append(word)
    return " ".join(processed_words)

def preprocess_document(doc_filename, stopwords):
    """Reads a document, preprocesses it, and writes the result to 'preproc_<doc_filename>'."""
    with open(doc_filename, "r", encoding="utf-8") as f:
        text = f.read()
    processed_text = preprocess_text(text, stopwords)
    out_filename = "preproc_" + doc_filename
    with open(out_filename, "w", encoding="utf-8") as f:
        f.write(processed_text) 
    return processed_text

def compute_tf_idf(preproc_docs):
    """
    Compute the Term Frequency - Inverse Document Frequency (TF-IDF) for each word in the documents.
    preproc_docs: dict mapping {document_name: [list_of_preprocessed_words]}
    Returns: dict mapping {document_name: [(word, tfidf_score), ...] for top 5 words}
    """
    total_docs = len(preproc_docs)

    doc_freq = defaultdict(int)
    for words in preproc_docs.values():
        unique_words = set(words)  
        for word in unique_words:
            doc_freq[word] += 1

    tfidf_results = {}
    for doc, words in preproc_docs.items():
        total_words = len(words)
        freq = Counter(words)  
        scores = {}
        for word, count in freq.items():
            tf = count / total_words  
            idf = math.log(total_docs / doc_freq[word]) + 1  
            tfidf = round(tf * idf, 2)  
            scores[word] = tfidf
        # Sort words by descending TF-IDF, then alphabetically for ties
        sorted_words = sorted(scores.items(), key=lambda x: (-x[1], x[0]))
        # Take top 5 words with highest TF-IDF scores
        top5 = sorted_words[:5]
        tfidf_results[doc] = top5
    return tfidf_results

def write_tfidf_results(doc, top5):
    """Writes the top-5 (word, TF-IDF) tuples to 'tfidf_<doc>' in list format."""
    out_filename = "tfidf_" + doc
    with open(out_filename, "w", encoding="utf-8") as f:
        f.write(str(top5))  # Save the TF-IDF results

def main():
    # Read the list of document filenames from "tfidf_docs.txt"
    with open("tfidf_docs.txt", "r", encoding="utf-8") as f:
        doc_list = [line.strip() for line in f if line.strip()]  # Read non-empty lines

    # Load stopwords
    stopwords = load_stopwords()

    # Preprocess each document
    preproc_texts = {}
    for doc in doc_list:
        processed_text = preprocess_document(doc, stopwords)
        preproc_texts[doc] = processed_text

    # Convert each preprocessed document to a list of words
    preproc_docs = {}
    for doc, text in preproc_texts.items():
        words = text.split()
        preproc_docs[doc] = words

    # Compute TF-IDF for each document
    tfidf_results = compute_tf_idf(preproc_docs)

    # Write top-5 TF-IDF words to file
    for doc, top5 in tfidf_results.items():
        write_tfidf_results(doc, top5)
    
    print("All files processed.")  


    pass
main()
