import socket
import os

# Client Configuration
HOST = "127.0.0.1"  # Server's IP address
PORT = 50007  # Must match server's port

try:
    # Create client socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))
    print("[C]: Client connected to server...")

    input_filename = os.path.join(os.path.dirname(__file__), "in-proj.txt")

    # Read input file and send data to server
    with open(input_filename, "r") as input_file:
        for line in input_file:
            line = line.strip()  # Remove leading/trailing spaces
            if not line:  # Skip empty lines
                continue

            print(f"[C]: Sending: {line}")  # Debugging

            # Encode the message and send the length first (fixed 4-byte length header)
            message = line.encode()
            client_socket.send(f"{len(message):04d}".encode())  # Send length first
            client_socket.send(message)  # Send actual message

            # Receive and print response from server
            response = client_socket.recv(1024).decode()
            if not response:
                break
            print(f"[C]: Sent: {line} | Received: {response}")  # Print output

            # Wait for acknowledgment before sending the next line
            ack = client_socket.recv(1)  
            if ack != b'1':
                print("[C]: Acknowledgment error.")
                break

    # Cleanup
    client_socket.shutdown(socket.SHUT_RDWR)
    client_socket.close()
    print("[C]: Client shut down.")

except Exception as e:
    print(f"[C]: Client error - {e}")
