import socket
import os

# Server Configuration
HOST = "0.0.0.0"  # Listen on all network interfaces
PORT = 50007  # Arbitrary non-privileged port

try:
    # Create server socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # Prevent "Address already in use" error
    server_socket.bind((HOST, PORT))
    server_socket.listen(1)
    print(f"[S]: Server listening on {HOST}:{PORT}...")

    conn, addr = server_socket.accept()
    print(f"[S]: Connection established with {addr}")

    output_filename = os.path.join(os.path.dirname(__file__), "out-proj.txt")

    with open(output_filename, "w") as output_file:
        while True:
            # Read message length (4 bytes)
            data_length = conn.recv(4).decode()
            if not data_length:
                break  # No more data

            # Read the actual message based on the received length
            data = conn.recv(int(data_length)).decode()
            if not data:
                break

            print(f"[S]: Received: {data}")  # Debugging

            # Reverse and swap case
            processed_data = data[::-1].swapcase().strip()  # Ensure no extra spaces

            print(f"[S]: Processed: {processed_data}")  # Debugging

            # Write to output file
            output_file.write(processed_data + "\n")
            output_file.flush()  # Ensure data is written immediately
            
            # Send processed message back to client
            conn.send(processed_data.encode())

            # Send acknowledgment byte to client
            conn.send(b'1')

    # Cleanup
    conn.shutdown(socket.SHUT_RDWR)
    conn.close()
    server_socket.close()
    print("[S]: Server shut down.")

except Exception as e:
    print(f"[S]: Server error - {e}")
