import socket
import signal
import sys
import random
from urllib.parse import parse_qs

# Read a command line argument for the port where the server must run.
port = 8080
if len(sys.argv) > 1:
    port = int(sys.argv[1])
else:
    print("Using default port 8080")
hostname = socket.gethostname()

# Start a listening server socket on the port
sock = socket.socket()
sock.bind(('', port))
sock.listen(2)

# Load user credentials and secrets
user_passwords = {}
user_secrets = {}
cookie_jar = {}  # cookie_value -> username

with open("passwords.txt", "r") as f:
    for line in f:
        username, password = line.strip().split()
        user_passwords[username] = password

with open("secrets.txt", "r") as f:
    for line in f:
        username, secret = line.strip().split()
        user_secrets[username] = secret

# HTML templates
login_form = """
   <form action = "http://%s" method = "post">
   Name: <input type = "text" name = "username">  <br/>
   Password: <input type = "text" name = "password" /> <br/>
   <input type = "submit" value = "Submit" />
   </form>
"""
login_page = "<h1>Please login</h1>" + login_form
bad_creds_page = "<h1>Bad user/pass! Try again</h1>" + login_form
logout_page = "<h1>Logged out successfully</h1>" + login_form
success_page = """
   <h1>Welcome!</h1>
   <form action="http://%s" method = "post">
   <input type = "hidden" name = "action" value = "logout" />
   <input type = "submit" value = "Click here to logout" />
   </form>
   <br/><br/>
   <h1>Your secret data is here:</h1>
"""

# Printing for debugging
def print_value(tag, value):
    print("Here is the", tag)
    print("\"\"\"")
    print(value)
    print("\"\"\"")
    print()

# Graceful exit on Ctrl+C
def sigint_handler(sig, frame):
    print('Finishing up by closing listening socket...')
    sock.close()
    sys.exit(0)

signal.signal(signal.SIGINT, sigint_handler)

# Main server loop
while True:
    client, addr = sock.accept()
    req = client.recv(4096)

    if not req:
        client.close()
        continue

    header_body = req.decode().split('\r\n\r\n')
    headers = header_body[0]
    body = '' if len(header_body) == 1 else header_body[1]

    if not headers.strip():
        client.close()
        continue

    print_value('headers', headers)
    print_value('entity body', body)

    lines = headers.split('\r\n')
    if not lines or not lines[0].strip():
        client.close()
        continue

    first_line = lines[0]
    method = first_line.split()[0]
    headers_dict = {}
    for line in lines[1:]:
        if ": " in line:
            key, val = line.split(": ", 1)
            headers_dict[key] = val

    cookie = headers_dict.get("Cookie", "")
    token = None
    username_from_cookie = None

    if "token=" in cookie:
        token = cookie.split("token=")[-1]
        if token in cookie_jar:
            username_from_cookie = cookie_jar[token]

    # Prepare form URL
    submit_hostport = headers_dict.get("Host", f"{hostname}:{port}")

    html_content_to_send = login_page % submit_hostport
    headers_to_send = ''

    # Parse POST data if available
    post_data = parse_qs(body)

    # Case E: Logout
    if 'action' in post_data and post_data['action'][0] == 'logout':
        headers_to_send = 'Set-Cookie: token=; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n'
        html_content_to_send = logout_page % submit_hostport

    # Case C: Valid Cookie
    elif username_from_cookie:
        secret = user_secrets.get(username_from_cookie, '')
        html_content_to_send = (success_page % submit_hostport) + secret

    # Case D: Invalid Cookie
    elif token:
        html_content_to_send = bad_creds_page % submit_hostport

    # Case A & B: Username/Password present
    elif 'username' in post_data and 'password' in post_data:
        username = post_data['username'][0]
        password = post_data['password'][0]
        if username in user_passwords and user_passwords[username] == password:
            rand_val = random.getrandbits(64)
            cookie_jar[str(rand_val)] = username
            headers_to_send = 'Set-Cookie: token=' + str(rand_val) + '\r\n'
            secret = user_secrets.get(username, '')
            html_content_to_send = (success_page % submit_hostport) + secret
        else:
            html_content_to_send = bad_creds_page % submit_hostport

    # Case B: One of the fields missing or mismatch
    elif ('username' in post_data) != ('password' in post_data):
        html_content_to_send = bad_creds_page % submit_hostport

    # Default: login page already set

    # Construct and send the HTTP response
    response  = 'HTTP/1.1 200 OK\r\n'
    response += headers_to_send
    response += 'Content-Type: text/html\r\n\r\n'
    response += html_content_to_send

    print_value('response', response)
    client.send(response.encode())
    client.close()

    print("Served one request/connection!\n")
