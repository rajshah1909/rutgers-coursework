import socket
import sys
import os

def read_hostnames(filename):
    """Read the list of domain names and resolution modes from a file."""
    hostnames = []
    try:
        with open(filename, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) == 2:
                    domain, mode = parts
                    hostnames.append((domain, mode))
    except FileNotFoundError:
        print(f"Error: Hostname file '{filename}' not found.")
        sys.exit(1)
    return hostnames

def log_response(response, log_filename="resolved.txt"):
    """Log the response to a file."""
    try:
        with open(log_filename, "a") as log:
            log.write(response + "\n")
            log.flush()  # Ensure immediate write to disk
        #print(f"Logged response: {response}")
        pass
    except Exception as e:
        print(f"Error writing to log file: {e}")

def resolve_domain(rs_hostname, rudns_port, domain, mode, identification):
    """Resolve a domain name using either iterative or recursive resolution."""
    query = f"0 {domain} {identification} {mode}"
    #print(f"Sending query to RS: {query}")
    pass
    
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as rs_socket:
            rs_socket.connect((rs_hostname, rudns_port))
            rs_socket.sendall(query.encode())
            response = rs_socket.recv(1024).decode().strip()
            #print(f"Received response from RS: {response}")
            pass
            
            # Log the response
            log_response(response)
            
            # Parse the response
            parts = response.split()
            if len(parts) != 5:
                print(f"Invalid response format: {response}")
                return identification
            
            response_type, response_domain, address, response_id, flag = parts
            
            # For iterative queries, may need to contact TS directly
            if flag == 'ns' and mode == 'it':
                # This is a referral to a TLD server
                ts_hostname = address
                new_identification = identification + 1
                new_query = f"0 {domain} {new_identification} {mode}"
                
                #print(f"Sending query to TS ({ts_hostname}): {new_query}")
                pass
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as ts_socket:
                    ts_socket.connect((ts_hostname, rudns_port))
                    ts_socket.sendall(new_query.encode())
                    ts_response = ts_socket.recv(1024).decode().strip()
                    #print(f"Received response from TS: {ts_response}")
                    pass
                    
                    # Log the response
                    log_response(ts_response)
                    return new_identification
            
            return identification
    
    except Exception as e:
        print(f"Error resolving domain {domain}: {e}")
        return identification

def main():
    """Main function to start the client."""
    if len(sys.argv) != 3:
        print("Usage: python3 client.py <rs_hostname> <port>")
        sys.exit(1)
    
    rs_hostname = sys.argv[1]
    rudns_port = int(sys.argv[2])
    
    hostnames = read_hostnames("hostnames.txt")
    
    # Create/clear the log file
    try:
        with open("resolved.txt", "w") as f:
            pass  # Create empty file or clear existing one
        print("Successfully created/cleared resolved.txt")
    except Exception as e:
        print(f"Warning: Could not create/clear log file: {e}")
    
    # Process each hostname in order
    identification = 1
    for domain, mode in hostnames:
        identification = resolve_domain(rs_hostname, rudns_port, domain, mode, identification)
        identification += 1

main()
