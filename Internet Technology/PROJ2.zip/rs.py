import socket
import sys
import os

def load_database(filename):
    """Load root server database containing TLD servers and direct mappings."""
    tld_servers = {}
    direct_mappings = {}
    
    try:
        with open(filename, 'r') as file:
            # First two lines are the TLD mappings
            line = file.readline().strip()
            if line:
                parts = line.split()
                if len(parts) == 2:
                    tld, server = parts
                    tld_servers[tld.lower()] = server
            
            line = file.readline().strip()
            if line:
                parts = line.split()
                if len(parts) == 2:
                    tld, server = parts
                    tld_servers[tld.lower()] = server
            
            # Rest of the lines are direct mappings
            for line in file:
                parts = line.strip().split()
                if len(parts) == 2:
                    domain, ip = parts
                    direct_mappings[domain.lower()] = (domain, ip)
    
    except FileNotFoundError:
        print(f"Error: Database file '{filename}' not found.")
        sys.exit(1)
    
    return tld_servers, direct_mappings

def get_tld(domain):
    """Extract the top-level domain from a domain name."""
    parts = domain.split('.')
    if len(parts) >= 2:
        return parts[-1].lower()
    return None

def handle_query(message, tld_servers, direct_mappings, rudns_port):
    """Process a DNS query and return a response string."""
    parts = message.split()
    if len(parts) != 4 or parts[0] != '0':
        print(f"Invalid query format: {message}")
        return ""
    
    # Extract fields from the query
    request_type, domain, identification, flag = parts
    domain_lower = domain.lower()
    tld = get_tld(domain_lower)
    
    # 1. If domain is directly in our database, return it immediately
    if domain_lower in direct_mappings:
        original_domain, ip = direct_mappings[domain_lower]
        return f"1 {original_domain} {ip} {identification} aa"
    
    # 2. If TLD is managed by a TLD server
    if tld in tld_servers:
        ts_hostname = tld_servers[tld]
        
        # Case 1: Iterative query (it)
        if flag == 'it':
            return f"1 {domain} {ts_hostname} {identification} ns"
        
        # Case 2: Recursive query (rd)
        elif flag == 'rd':
            # Forward the query to the TLD server
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as ts_socket:
                    ts_socket.connect((ts_hostname, rudns_port))
                    ts_socket.sendall(message.encode())
                    response = ts_socket.recv(1024).decode().strip()
                    
                    # Parse the response
                    response_parts = response.split()
                    if len(response_parts) != 5:
                        return ""
                    
                    response_type, response_domain, ip_address, response_id, response_flag = response_parts
                    
                    # If authoritative answer, change flag to ra
                    if response_flag == 'aa':
                        return f"1 {response_domain} {ip_address} {response_id} ra"
                    # Otherwise, pass through nx flag
                    return response
            except Exception as e:
                print(f"Error contacting TS server {ts_hostname}: {e}")
                return f"1 {domain} 0.0.0.0 {identification} nx"
    
    # 3. Domain not in our database and TLD not managed by any TS
    return f"1 {domain} 0.0.0.0 {identification} nx"

def log_response(response, log_filename="rsresponses.txt"):
    """Log the response to a file."""
    try:
        with open(log_filename, "a") as log:
            log.write(response + "\n")
            log.flush()  # Ensure immediate write to disk
        #print(f"Logged response: {response}")
        pass
    except Exception as e:
        print(f"Error writing to log file: {e}")

def main():
    """Main function to start the RS server."""
    if len(sys.argv) != 2:
        print("Usage: python3 rs.py <port>")
        sys.exit(1)
    
    port = int(sys.argv[1])
    tld_servers, direct_mappings = load_database("rsdatabase.txt")
    
    # Print the loaded data for debugging
    #print(f"TLD Servers: {tld_servers}")
    #print(f"Direct Mappings: {direct_mappings}")
    
    # Create/clear the log file
    try:
        with open("rsresponses.txt", "w") as f:
            pass  # Create empty file or clear existing one
        print("Successfully created/cleared rsresponses.txt")
    except Exception as e:
        print(f"Warning: Could not create/clear log file: {e}")
    
    # Create and setup server socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind(("", port))  # Bind to all available interfaces
        server_socket.listen(5)
        print(f"RS Server is running on port {port}...")
        
        while True:
            try:
                conn, addr = server_socket.accept()
                #print(f"Connection received from {addr}")
                pass
                
                with conn:
                    data = conn.recv(1024)
                    if not data:
                        continue
                    
                    query = data.decode().strip()
                    #print(f"Received query: {query}")
                    pass
                    
                    response = handle_query(query, tld_servers, direct_mappings, port)
                    if response:
                        conn.sendall(response.encode())
                        log_response(response)
                    else:
                        print("Invalid query format received.")
            except Exception as e:
                print(f"Error in handling request: {e}")

main()
