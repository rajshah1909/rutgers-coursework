import socket
import sys
import os

def load_database(filename):
    """Load domain-to-IP mappings from a file."""
    database = {}
    try:
        with open(filename, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) == 2:  # Valid line with domain and IP
                    domain, ip = parts
                    database[domain.lower()] = (domain, ip)  # Store original domain case and IP
    except FileNotFoundError:
        print(f"Error: Database file '{filename}' not found.")
        sys.exit(1)
    return database

def handle_query(message, database):
    """Process a DNS query and return a response string."""
    parts = message.split()
    if len(parts) != 4 or parts[0] != '0':
        print(f"Invalid query format: {message}")
        return ""
    
    # Extract fields from the query
    request_type, domain, identification, flag = parts
    domain_lower = domain.lower()
    
    # Check if domain exists in the database
    if domain_lower in database:
        original_domain, ip = database[domain_lower]
        return f"1 {original_domain} {ip} {identification} aa"
    
    # Domain not found
    return f"1 {domain} 0.0.0.0 {identification} nx"

def log_response(response, log_filename="ts1responses.txt"):
    """Log the response to a file."""
    try:
        with open(log_filename, "a") as log:
            log.write(response + "\n")
            log.flush()  # Ensure immediate write to disk
        #print(f"Logged response: {response}")
        pass
    except Exception as e:
        print(f"Error writing to log file: {e}")

def main():
    """Main function to start the TS1 server."""
    if len(sys.argv) != 2:
        print("Usage: python3 ts1.py <port>")
        sys.exit(1)
    
    port = int(sys.argv[1])
    database = load_database("ts1database.txt")
    
    # Create/clear the log file
    try:
        with open("ts1responses.txt", "w") as f:
            pass  # Create empty file or clear existing one
        print("Successfully created/cleared ts1responses.txt")
    except Exception as e:
        print(f"Warning: Could not create/clear log file: {e}")
    
    # Create and setup server socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind(("", port))  # Bind to all available interfaces
        server_socket.listen(5)
        print(f"TS1 Server is running on port {port}...")
        
        while True:
            try:
                conn, addr = server_socket.accept()
                #print(f"Connection received from {addr}")
                pass
                
                with conn:
                    data = conn.recv(1024)
                    if not data:
                        continue
                    
                    query = data.decode().strip()
                    #print(f"Received query: {query}")
                    pass
                    
                    response = handle_query(query, database)
                    if response:
                        conn.sendall(response.encode())
                        log_response(response)
                    else:
                        print("Invalid query format received.")
            except Exception as e:
                print(f"Error in handling request: {e}")

main()
